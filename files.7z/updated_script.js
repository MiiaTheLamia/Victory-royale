let orders = [];
let currentWeek = 1;
let currentWeekNumber = getWeekNumber(new Date());
let nextWeekNumber = currentWeekNumber + 1;

function loadOrders() {
    fetch('/orders')
        .then(response => response.json())
        .then(data => {
            orders = data;
            displayOrders();
        })
        .catch(error => console.error('Error loading orders:', error));
}

function saveOrder(order) {
    fetch('/orders', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(order)
    })
    .then(response => response.text())
    .then(message => console.log(message))
    .catch(error => console.error('Error saving order:', error));
}

function addOrder() {
    const orderNumber = document.getElementById('order-number').value;
    const description = document.getElementById('description').value;
    const technician = document.getElementById('technician').value;
    const location = document.getElementById('location').value;
    const executionTime = document.getElementById('execution-time').value;
    const endTime = document.getElementById('end-time').value;
    const weekValue = document.getElementById('week-create') ? parseInt(document.getElementById('week-create').value) : currentWeek; // Gebruik `week-create` als deze bestaat

    if (!orderNumber || !technician || !location || !executionTime || !endTime) {
        alert('Vul alstublieft alle velden in!');
        return;
    }

    // Bereken de duur van de order
    const duration = calculateDuration(executionTime, endTime);
    if (duration === null) {
        alert('Eindtijd moet later zijn dan uitvoeringstijd.');
        return;
    }

    // Maak de order
    const order = {
        id: Date.now(),
        orderNumber,
        description,
        technician,
        location,
        executionTime,
        endTime,
        duration,
        completed: false,
        week: weekValue === 0 ? currentWeek : weekValue, // Gebruik huidige week als waarde 0 is
        day: document.getElementById('day').value // Dag wordt nog steeds uit het formulier gehaald
    };

    // Voeg de order toe aan de lijst
    orders.push(order);
    displayOrders();
    saveOrder(order);

    // Reset het formulier
    resetForm();
    closeOrderForm();
}


function calculateDuration(startTime, endTime) {
    if (!startTime || !endTime) {
        return null;
    }

    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);

    const startDate = new Date();
    startDate.setHours(startHours, startMinutes, 0);

    const endDate = new Date();
    endDate.setHours(endHours, endMinutes, 0);

    if (endDate <= startDate) {
        return null;
    }

    const durationInMinutes = (endDate - startDate) / (1000 * 60);
    const hours = Math.floor(durationInMinutes / 60);
    const minutes = durationInMinutes % 60;

    return `${hours} uur en ${minutes} minuten`;
}

function resetForm() {
    document.getElementById('order-number').value = '';
    document.getElementById('description').value = '';
    document.getElementById('technician').value = '';
    document.getElementById('location').value = '';
    document.getElementById('day').value = 'monday';
    document.getElementById('execution-time').value = '';
    document.getElementById('end-time').value = '';
}

function displayOrders() {
    const daysWeek1 = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    const daysWeek2 = ['monday-week-2', 'tuesday-week-2', 'wednesday-week-2', 'thursday-week-2', 'friday-week-2'];

    // Reset inhoud van alle dagen
    [...daysWeek1, ...daysWeek2].forEach(day => {
        const dayDiv = document.getElementById(day);
        let ordersContainer = dayDiv.querySelector('.orders-container');

        if (!ordersContainer) {
            // Maak een nieuwe container als deze niet bestaat
            ordersContainer = document.createElement('div');
            ordersContainer.classList.add('orders-container');
            dayDiv.appendChild(ordersContainer);
        }

        // Reset alleen de orders-container
        ordersContainer.innerHTML = '';
    });

    // Werk de daglabels bij voor week 2
    daysWeek2.forEach(day => {
        const dayDiv = document.getElementById(day);
        const ordersContainer = dayDiv.querySelector('.orders-container');
        dayDiv.innerHTML = `<h2>${day.split('-')[0].charAt(0).toUpperCase() + day.split('-')[0].slice(1)}</h2>`;
        dayDiv.appendChild(ordersContainer); // Zorg dat de container blijft bestaan
    });

    // Reset en toon voltooide orders
    const completedOrdersDiv = document.getElementById('completed-orders');
    completedOrdersDiv.innerHTML = `
        <h2>Voltooide Orders</h2>
        <div id="completed-orders-buttons">
            <button id="delete-completed-orders-btn" style="margin: 20px 0;" onclick="deleteCompletedOrders()">Verwijder Voltooide Orders</button>
        </div>
    `;

    let hasCompletedOrders = false;

    // Voeg orders toe aan de juiste dagen
    orders.forEach(order => {
        const orderDiv = document.createElement('div');
        orderDiv.classList.add('order');
        orderDiv.draggable = true;
        orderDiv.ondragstart = drag;
        orderDiv.id = `order-${order.id}`;

        // Voeg specifieke klasse toe op basis van monteur
        let technicianClass = '';
        switch (order.technician) {
            case 'WTB': technicianClass = 'wtb'; break;
            case 'MeRe': technicianClass = 'mere'; break;
            case 'Roodhart': technicianClass = 'roodhart'; break;
            case 'PCN': technicianClass = 'pcn'; break;
            case 'Extern': technicianClass = 'extern'; break;
        }
        orderDiv.classList.add(technicianClass);

        if (order.completed) {
            orderDiv.classList.add('completed');
            orderDiv.innerHTML = `<h3 onclick="showCompletedOrderDetails(${order.id})" style="cursor: pointer;">${order.orderNumber}</h3>`;
            completedOrdersDiv.appendChild(orderDiv);
            hasCompletedOrders = true;
        } else {
            orderDiv.innerHTML = `
                <h3 onclick="showOrderDetails(${order.id})" style="cursor: pointer;">${order.orderNumber}</h3>
                <p>${order.technician}</p>
                <p>${order.location}</p>
                <p>${order.executionTime} - ${order.endTime}</p>
            `;

            const targetDay = order.week === 1 ? order.day : `${order.day}-week-2`;
            const dayDiv = document.getElementById(targetDay);
            const ordersContainer = dayDiv.querySelector('.orders-container');
            ordersContainer.appendChild(orderDiv);
        }
    });

    // Toon of verberg voltooide orders-sectie
    if (hasCompletedOrders) {
        completedOrdersDiv.style.display = 'block';
    } else {
        completedOrdersDiv.style.display = 'none';
    }
}

function navigateWeek(direction) {
    // Verberg de huidige week
    const currentWeekElement = document.getElementById(`calendar-week-${currentWeek}`);
    if (currentWeekElement) {
        currentWeekElement.classList.remove('active-week');
        currentWeekElement.style.display = "none"; // Verberg de week
    }

    // Bepaal de nieuwe week
    currentWeek += direction;
    if (currentWeek < 1) currentWeek = 2; // Cirkel naar de laatste week
    if (currentWeek > 2) currentWeek = 1; // Cirkel terug naar de eerste week

    // Toon de nieuwe week
    const newWeekElement = document.getElementById(`calendar-week-${currentWeek}`);
    if (newWeekElement) {
        newWeekElement.classList.add('active-week');
        newWeekElement.style.display = "flex"; // Zorg dat de week flex-layout gebruikt
    }
}

// Initialiseer de actieve week bij het laden van de pagina
document.addEventListener('DOMContentLoaded', () => {
    const initialWeek = document.getElementById(`calendar-week-${currentWeek}`);
    if (initialWeek) {
        initialWeek.classList.add('active-week');
        initialWeek.style.display = 'flex'; // Zorg dat de eerste week zichtbaar is
    }
});
// Function to delete completed orders
function deleteCompletedOrders() {
    orders = orders.filter(order => !order.completed);
    displayOrders();
    saveOrders();
}

// Function to reopen an order
function reopenOrder(index) {
    orders[index].completed = false;
    orders[index].completedDate = null;
    saveOrder(orders[index]);
    displayOrders();
    closeOrderForm(); // Close the modal after reopening
}

// Function to show completed order details
function showCompletedOrderDetails(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (!order) {
        alert("Order niet gevonden.");
        return;
    }

    const modal = document.getElementById('order-form');
    const modalContent = modal.querySelector('.modal-content');
    modalContent.innerHTML = `
        <span class="close" onclick="closeOrderForm()">&times;</span>
        <h2>Ordernummer: ${order.orderNumber}</h2>
        <p>Voltooid op: ${order.completedDate || "Onbekend"}</p>
        <p>Beschrijving: ${order.description}</p>
        <p>Monteur: ${order.technician}</p>
        <p>Locatie: ${order.location}</p>
        <p>Uitvoeringstijd: ${order.executionTime} - ${order.endTime}</p>
        <div class="buttons">
            <button class="reopen-btn" onclick="handleReopen(${orders.indexOf(order)})">Heropen</button>
        </div>
    `;
    modal.style.display = 'flex';
}

function handleReopen(index) {
    reopenOrder(index);
    closeOrderForm(); // Zorg dat het venster wordt gesloten
}

function reopenOrder(index) {
    orders[index].completed = false;
    orders[index].completedDate = null;
    displayOrders();
    saveOrder(orders[index]);
}

// Function to show uncompleted order details
function showOrderDetails(orderId, isEditable = false) {
    const order = orders.find(o => o.id === orderId);
    if (!order) {
        alert("Order niet gevonden.");
        return;
    }

    const modal = document.getElementById('order-form');
    const modalContent = modal.querySelector('.modal-content');

    if (!isEditable) {
        // Bekijken modus
        modalContent.innerHTML = `
            <h2>Ordernummer: ${order.orderNumber}</h2>
            <p><strong>Beschrijving:</strong> ${order.description}</p>
            <p><strong>Monteur:</strong> ${order.technician}</p>
            <p><strong>Locatie:</strong> ${order.location}</p>
            <p><strong>Uitvoeringstijd:</strong> ${order.executionTime} - ${order.endTime}</p>
            <p><strong>Week:</strong> ${order.week === 1 ? 'Huidige Week' : 'Volgende Week'}</p>
            <div class="buttons">
                <button class="copy-btn" onclick="copyToNextDay(${orders.indexOf(order)})">Kopieer naar volgende dag</button>
                <button class="complete-btn" onclick="markOrderAsCompleted(${orders.indexOf(order)})">Voltooien</button>
                <button class="edit-btn" onclick="showOrderDetails(${orderId}, true)">Wijzigen</button>
                <button class="close-btn" onclick="closeOrderForm()">Sluiten</button>
            </div>
        `;
    } else {
        // Bewerken modus
        modalContent.innerHTML = `
            <h2>Ordernummer: ${order.orderNumber}</h2>
            <label for="description-edit">Beschrijving:</label>
            <textarea id="description-edit">${order.description}</textarea>
            <label for="technician-edit">Monteur:</label>
            <select id="technician-edit">
                <option value="WTB" ${order.technician === 'WTB' ? 'selected' : ''}>WTB</option>
                <option value="MeRe" ${order.technician === 'MeRe' ? 'selected' : ''}>MeRe</option>
                <option value="Roodhart" ${order.technician === 'Roodhart' ? 'selected' : ''}>Roodhart</option>
                <option value="PCN" ${order.technician === 'PCN' ? 'selected' : ''}>PCN</option>
                <option value="Extern" ${order.technician === 'Extern' ? 'selected' : ''}>Extern</option>
            </select>
            <label for="location-edit">Locatie:</label>
            <input type="text" id="location-edit" value="${order.location}">
            <label for="day-edit">Dag:</label>
            <select id="day-edit">
                <option value="monday" ${order.day === 'monday' ? 'selected' : ''}>Maandag</option>
                <option value="tuesday" ${order.day === 'tuesday' ? 'selected' : ''}>Dinsdag</option>
                <option value="wednesday" ${order.day === 'wednesday' ? 'selected' : ''}>Woensdag</option>
                <option value="thursday" ${order.day === 'thursday' ? 'selected' : ''}>Donderdag</option>
                <option value="friday" ${order.day === 'friday' ? 'selected' : ''}>Vrijdag</option>
            </select>
            <label for="week-edit">Week:</label>
            <select id="week-edit">
                <option value="1" ${order.week === 1 ? 'selected' : ''}>Huidige Week</option>
                <option value="2" ${order.week === 2 ? 'selected' : ''}>Volgende Week</option>
            </select>
            <label for="execution-time-edit">Uitvoeringstijd:</label>
            <input type="time" id="execution-time-edit" value="${order.executionTime}">
            <label for="end-time-edit">Eindtijd:</label>
            <input type="time" id="end-time-edit" value="${order.endTime}">
            <div class="buttons">
                <button class="save-btn" onclick="updateOrder(${orders.indexOf(order)})">Opslaan</button>
                <button class="close-btn" onclick="closeOrderForm()">Annuleren</button>
            </div>
        `;
    }

    modal.style.display = 'flex';
}

function updateOrder(index) { 
    const updatedOrder = orders[index];
    updatedOrder.description = document.getElementById('description-edit').value.trim();
    updatedOrder.technician = document.getElementById('technician-edit').value;
    updatedOrder.location = document.getElementById('location-edit').value.trim();
    updatedOrder.executionTime = document.getElementById('execution-time-edit').value;
    updatedOrder.endTime = document.getElementById('end-time-edit').value;
    updatedOrder.day = document.getElementById('day-edit').value;

    const weekValue = parseInt(document.getElementById('week-edit').value);

    // Debugging: Log de huidige week en de waarde van week-edit
    console.log(`Geselecteerde week: ${weekValue}, Vorige week: ${currentWeek}`);

    // Logica voor week bijwerken
    if (!isNaN(weekValue)) {
        updatedOrder.week = weekValue === 0 ? currentWeek : weekValue; // Gebruik huidige week als waarde 0 is
    } else {
        alert("Ongeldige waarde voor week geselecteerd!");
        return;
    }

    // Validatie
    if (!updatedOrder.description || !updatedOrder.location || !updatedOrder.executionTime || !updatedOrder.endTime) {
        alert("Vul alstublieft alle velden correct in.");
        return;
    }

    // Controleer of de eindtijd logisch is
    const duration = calculateDuration(updatedOrder.executionTime, updatedOrder.endTime);
    if (!duration) {
        alert("Eindtijd moet later zijn dan uitvoeringstijd.");
        return;
    }

    // Werk de order bij in de array
    orders[index] = updatedOrder;

    // Update de UI en backend
    displayOrders(); // Orders opnieuw weergeven
    saveOrder(updatedOrder); // Wijzigingen opslaan
    closeOrderForm(); // Sluit het formulier

    console.log(`Order bijgewerkt: Week ${updatedOrder.week}, Dag ${updatedOrder.day}`);
}


function toggleDetails(orderId) {
    const detailsDiv = document.getElementById(`details-${orderId}`);
    if (detailsDiv.style.display === 'none') {
        detailsDiv.style.display = 'block';
    } else {
        detailsDiv.style.display = 'none';
    }
}


function markOrderAsCompleted(index) {
    orders[index].completed = true;
    orders[index].completedDate = new Date().toLocaleString(); // Voeg de voltooiingsdatum toe
    displayOrders(); // Update de UI
    saveOrder(orders[index]); // Sla de wijziging op

    // Sluit de modal
    closeOrderForm();
}

function reopenOrder(index) {
    orders[index].completed = false;
    orders[index].completedDate = null; // Verwijder de voltooiingsdatum
    displayOrders();
    saveOrder(orders[index]);
}

function drag(event) {
    event.dataTransfer.setData("text", event.target.id);
    console.log('Dragging:', event.target.id); // Debug
}

function allowDrop(event) {
    event.preventDefault();
    console.log('Allowing drop:', event.target.id); // Debug
}

function drop(event) {
    event.preventDefault();
    const data = event.dataTransfer.getData("text");
    const orderDiv = document.getElementById(data);
    const targetDay = event.target.id;

    // Controleer of het een geldige dag is
    const validDays = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday',
                       'monday-week-2', 'tuesday-week-2', 'wednesday-week-2', 'thursday-week-2', 'friday-week-2'];
    if (!validDays.includes(targetDay)) {
        alert('Je kunt alleen orders naar een geldige dag slepen.');
        return;
    }

    const orderId = parseInt(orderDiv.id.split('-')[1]);
    const order = orders.find(o => o.id === orderId);

    // Update de week en dag van de order
    if (targetDay.includes('week-2')) {
        order.week = 2;
        order.day = targetDay.split('-')[0];
    } else {
        order.week = 1;
        order.day = targetDay;
    }

    displayOrders();
    saveOrder(order);
}

function copyToNextDay(index) {
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    const currentDayIndex = days.indexOf(orders[index].day);
    const nextDayIndex = (currentDayIndex + 1) % days.length;
    const nextDay = days[nextDayIndex];

    // Controleer of het ordernummer al bestaat op de volgende dag
    if (orders.some(order => order.orderNumber === orders[index].orderNumber && order.day === nextDay)) {
        alert('Dit ordernummer bestaat al op de volgende dag. Gebruik een uniek ordernummer of kies een andere dag.');
        return;
    }

    const newOrder = { ...orders[index], id: Date.now(), day: nextDay };
    orders.push(newOrder);
    displayOrders();
    saveOrder(newOrder);
}

function saveOrders() {
    fetch('/orders', {
        method: 'PUT', // Gebruik PUT om de bestaande lijst bij te werken
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(orders)
    })
    .then(response => response.text())
    .then(message => console.log(message))
    .catch(error => console.error('Error saving orders:', error));
}

function showOrderForm() {
    const modal = document.getElementById('order-form');
    const modalContent = modal.querySelector('.modal-content');
    
    // Reset de inhoud van de modal
    modalContent.innerHTML = `
        <span class="close" onclick="closeOrderForm()">&times;</span>
        <input type="text" id="order-number" placeholder="Ordernummer">
        <textarea id="description" placeholder="Beschrijving"></textarea>
        <div class="form-row">
            <select id="technician">
                <option value="" disabled selected>Selecteer Monteur</option>
                <option value="WTB">WTB</option>
                <option value="MeRe">MeRe</option>
                <option value="" disabled style="text-align: center;">--------------Extern---------------</option>
                <option value="Roodhart">Roodhart</option>
                <option value="PCN">PCN</option>
                <option value="Extern">Overige externe</option>
            </select>
            <input type="text" id="location" placeholder="Locatie">
        </div>
        <select id="day">
            <option value="monday">Maandag</option>
            <option value="tuesday">Dinsdag</option>
            <option value="wednesday">Woensdag</option>
            <option value="thursday">Donderdag</option>
            <option value="friday">Vrijdag</option>
        </select>
        <div class="form-row tijd-row">
            <div class="tijd-container">
                <label for="execution-time">Uitvoeringstijd</label>
                <input type="time" id="execution-time" placeholder="Starttijd">
            </div>
            <div class="tijd-container">
                <label for="end-time">Eindtijd</label>
                <input type="time" id="end-time" placeholder="Eindtijd">
            </div>
        </div>
        <button onclick="addOrder()">Voeg Order Toe</button>
    `;
    modal.style.display = 'flex';
}

function closeOrderForm() {
    document.getElementById('order-form').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    loadOrders();

    // Bereken het huidige weeknummer en vervang de titel
    const currentWeekNumber = getWeekNumber(new Date());
    console.log("Current week number: ", currentWeekNumber); // Controleer of het weeknummer correct wordt berekend

    const titleElement = document.getElementById('title');
    if (titleElement) {
        titleElement.textContent = `Week ${currentWeekNumber}`;
    } else {
        console.error("Element met id 'title' niet gevonden.");
    }
});

function getWeekNumber(date) {
    // Maak een nieuwe datum gebaseerd op de huidige datum, waarbij de tijd wordt verwijderd
    const target = new Date(date.valueOf());
    target.setHours(0, 0, 0, 0);

    // Stel de eerste dag van het jaar in
    const yearStart = new Date(target.getFullYear(), 0, 1);
    const dayOfYear = ((target - yearStart) / 86400000) + 1;

    // Bereken de week
    return Math.ceil(dayOfYear / 7);
}

function updateWeekLabels() {
    document.querySelector("#calendar-week-1 h2").textContent = `Week ${currentWeekNumber}`;
    document.querySelector("#calendar-week-2 h2").textContent = `Week ${nextWeekNumber}`;
}

// Initialiseer de weeklabels bij het laden van de pagina
document.addEventListener("DOMContentLoaded", () => {
    updateWeekLabels();
});

function copyToNextDay(index) {
    const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    const currentDayIndex = days.indexOf(orders[index].day);
    const nextDayIndex = (currentDayIndex + 1) % days.length;
    const nextDay = days[nextDayIndex];

    // Controleer of het ordernummer al bestaat op de volgende dag
    if (orders.some(order => order.orderNumber === orders[index].orderNumber && order.day === nextDay)) {
        alert('Dit ordernummer bestaat al op de volgende dag. Gebruik een uniek ordernummer of kies een andere dag.');
        return;
    }

    const newOrder = { ...orders[index], id: Date.now(), day: nextDay };
    orders.push(newOrder);
    displayOrders();
    saveOrder(newOrder);

    // Sluit de modal
    closeOrderForm();
}

function deleteCompletedOrders() {
    // Filter de lijst om alleen onvoltooide orders te behouden
    orders = orders.filter(order => !order.completed);
    
    // Werk de UI bij
    displayOrders();

    // Sla de nieuwe lijst op
    saveOrders(); // Zorg dat deze functie je orders naar de backend opslaat, of pas het aan.
}

function reopenCompletedOrders() {
    // Itereer over de orders en markeer voltooide orders als niet-voltooid
    orders.forEach(order => {
        if (order.completed) {
            order.completed = false;
            order.completedDate = null; // Reset de voltooiingsdatum
        }
    });

    // Werk de UI bij
    displayOrders();

    // Sla de gewijzigde orders op naar de backend
    saveOrders();
}

document.addEventListener('DOMContentLoaded', function () {
    // Verberg alle weken behalve de actieve
    const weeks = document.querySelectorAll('.week');
    weeks.forEach((week, index) => {
        if (index + 1 === currentWeek) {
            week.classList.add('active-week');
            week.style.display = 'flex'; // Zorg dat de actieve week zichtbaar is
        } else {
            week.style.display = 'none'; // Verberg andere weken
        }
    });

    // Debug informatie
    console.log(`Week ${currentWeek} is actief.`);
});
window.onload = loadOrders;
